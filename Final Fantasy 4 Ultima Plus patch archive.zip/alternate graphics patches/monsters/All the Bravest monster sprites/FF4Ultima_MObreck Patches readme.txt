FF4Ultima_MObreckPatches.zip
by MObreck, v2022

Patches:
-The Goblin "All The Bravest" sprite replacer
-The Cockatrice, Red Giant, and Coeurl "All The Bravest" sprites replacer

These patches need Ultima and Gedankenschild's 4BPP patch installed to work properly!